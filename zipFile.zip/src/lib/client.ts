import { createEdgeSpark } from "@edgespark/client";
import "@edgespark/client/styles.css";

// Initialize the client
export const client = createEdgeSpark({
  baseUrl: "https://staging--c8yscckgjqswzrju1iaw.youbase.cloud"
});
