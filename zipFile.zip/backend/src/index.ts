import { Hono } from "hono";
import type { Client } from "@sdk/server-types";
import { tables } from "@generated";
import { desc } from "drizzle-orm";

export async function createApp(
  edgespark: Client<typeof tables>
): Promise<Hono> {
  const app = new Hono();

  // --- Bots ---
  app.get('/api/bots', async (c) => {
    const allBots = await edgespark.db.select().from(tables.bots);
    return c.json(allBots);
  });

  app.post('/api/bots', async (c) => {
    const body = await c.req.json();
    
    if (Array.isArray(body)) {
      for (const bot of body) {
        // Ensure we don't try to insert unknown fields if the frontend sends extra data
        const { id, name, type, status, uptime, load } = bot;
        await edgespark.db.insert(tables.bots).values({
            id, name, type, status, uptime, load
        }).onConflictDoUpdate({
          target: tables.bots.id,
          set: { name, type, status, uptime, load }
        });
      }
    } else {
       const { id, name, type, status, uptime, load } = body;
       await edgespark.db.insert(tables.bots).values({
           id, name, type, status, uptime, load
       }).onConflictDoUpdate({
          target: tables.bots.id,
          set: { name, type, status, uptime, load }
        });
    }
    return c.json({ success: true });
  });

  // --- Files ---
  app.get('/api/files', async (c) => {
    const allFiles = await edgespark.db.select().from(tables.files).orderBy(desc(tables.files.createdAt));
    return c.json(allFiles);
  });

  app.post('/api/files', async (c) => {
    const body = await c.req.json();
    if (Array.isArray(body)) {
       for (const file of body) {
        const { id, name, type, size, date, author, content } = file;
        await edgespark.db.insert(tables.files).values({
            id, name, type, size, date, author, content
        }).onConflictDoUpdate({
          target: tables.files.id,
          set: { name, type, size, date, author, content }
        });
      }
    } else {
        const { id, name, type, size, date, author, content } = body;
        await edgespark.db.insert(tables.files).values({
            id, name, type, size, date, author, content
        }).onConflictDoUpdate({
          target: tables.files.id,
          set: { name, type, size, date, author, content }
        });
    }
    return c.json({ success: true });
  });

  // --- Logs ---
  app.get('/api/logs', async (c) => {
    const allLogs = await edgespark.db.select().from(tables.logs).orderBy(desc(tables.logs.id)).limit(100);
    return c.json(allLogs);
  });

  app.post('/api/logs', async (c) => {
    const body = await c.req.json();
    // Logs might come without ID (auto-increment)
    // If frontend sends ID, we might ignore it or use it.
    // Frontend Log interface has ID.
    // But usually logs are new events.
    
    if (Array.isArray(body)) {
        for (const log of body) {
            const { timestamp, level, message } = log;
            await edgespark.db.insert(tables.logs).values({ timestamp, level, message });
        }
    } else {
        const { timestamp, level, message } = body;
        await edgespark.db.insert(tables.logs).values({ timestamp, level, message });
    }
    return c.json({ success: true });
  });

  return app;
}
