# Sovereign Console v2 — Portable Template

This zip contains a **working, clean version** of the Sovereign Console v2 concept:

✅ Dashboard (Vite + React)
✅ Backend API (Node + Express)
✅ Login (cookie session)
✅ Workspace browser + file editor
✅ Safe terminal runner (allowlist)
✅ AI assistant endpoint (Ollama proxy with timeout safety)

## Run
```bash
cd sovereign_console_v2_template
./run_scv2.sh
```
Open:
- http://127.0.0.1:5173

Default login:
- **user:** admin
- **pass:** admin

See full docs:
- `apps/sovereign_console_v2/README.md`
- `AI_WORKFLOW.md`
