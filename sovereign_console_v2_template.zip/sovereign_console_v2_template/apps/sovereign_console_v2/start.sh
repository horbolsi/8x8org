#!/usr/bin/env bash
set -euo pipefail

APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "$APP_DIR/../.." && pwd)"
BACK="$APP_DIR/backend"
FRONT="$APP_DIR/frontend"

mkdir -p "$APP_DIR/runtime/logs"

export WORKSPACE_ROOT="${WORKSPACE_ROOT:-$ROOT_DIR}"
export PORT="${PORT:-6060}"

echo "==> Starting Sovereign Console v2"
echo "✅ WORKSPACE_ROOT = $WORKSPACE_ROOT"
echo "✅ PORT = $PORT"

echo "==> Installing backend deps (if needed)"
(cd "$BACK" && npm i >/dev/null)

echo "==> Starting backend"
(cd "$BACK" && npm run dev > "$APP_DIR/runtime/logs/backend.out" 2>&1 &)

echo "==> Waiting backend..."
for i in $(seq 1 80); do
  if curl -sS "http://127.0.0.1:${PORT}/api/health" >/dev/null 2>&1; then
    echo "✅ Backend ready: http://127.0.0.1:${PORT}"
    break
  fi
  sleep 0.25
done

echo "==> Installing frontend deps (if needed)"
(cd "$FRONT" && npm i >/dev/null)

echo "==> Starting frontend"
(cd "$FRONT" && npm run dev > "$APP_DIR/runtime/logs/frontend.out" 2>&1 &)

echo
echo "✅ Backend:  http://127.0.0.1:${PORT}"
echo "✅ Frontend: http://127.0.0.1:5173"
echo
echo "Logs:"
echo "  $APP_DIR/runtime/logs/backend.out"
echo "  $APP_DIR/runtime/logs/frontend.out"
