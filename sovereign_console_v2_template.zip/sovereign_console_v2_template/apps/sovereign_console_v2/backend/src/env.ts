import { z } from "zod";

const schema = z.object({
  PORT: z.coerce.number().default(6060),
  WORKSPACE_ROOT: z.string().default(process.cwd()),

  ADMIN_USER: z.string().default("admin"),
  ADMIN_PASS: z.string().default("admin"),
  SESSION_SECRET: z.string().default("change-me"),

  OLLAMA_URL: z.string().default("http://127.0.0.1:11434"),
  OLLAMA_MODEL: z.string().default("llama3.1"),
  OLLAMA_TIMEOUT_MS: z.coerce.number().default(120000)
});

export type Env = z.infer<typeof schema>;

export function loadEnv(): Env {
  // NOTE: We avoid dotenv dependency for portability.
  // If you want .env auto-load, you can `source backend/.env` before start.
  const parsed = schema.safeParse(process.env);
  if (!parsed.success) {
    // Use defaults if missing
    const fallback = schema.parse({});
    return fallback;
  }
  return parsed.data;
}
