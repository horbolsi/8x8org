import express from "express";
import cors from "cors";
import cookieParser from "cookie-parser";
import crypto from "crypto";
import path from "path";
import fs from "fs/promises";
import { spawn } from "child_process";

// =====================
// Config
// =====================
const PORT = Number(process.env.PORT || 6060);
const ADMIN_USER = process.env.ADMIN_USER || "admin";
const ADMIN_PASS = process.env.ADMIN_PASS || "admin";
const SESSION_COOKIE = process.env.SESSION_COOKIE || "scv2_session";
const WORKSPACE_ROOT = path.resolve(process.env.WORKSPACE_ROOT || path.join(process.cwd(), "..", "..", ".."));
const OLLAMA_URL = (process.env.OLLAMA_URL || "http://127.0.0.1:11434").replace(/\/$/, "");
const OLLAMA_MODEL = process.env.OLLAMA_MODEL || "llama3.2";
const OLLAMA_TIMEOUT_MS = Number(process.env.OLLAMA_TIMEOUT_MS || 20000);

// Allowlist for command execution (admin-only)
const EXEC_ALLOWLIST = new Set(
  (process.env.EXEC_ALLOWLIST || "rg,ls,cat,head,tail,sed,tree,git,npm,node,python3")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean)
);

const EXEC_DENY_PATTERNS = [
  /(^|\s)rm(\s|$)/,
  /(^|\s)mv(\s|$)/,
  /(^|\s)dd(\s|$)/,
  /mkfs/i,
  /shutdown/i,
  /reboot/i,
  /chmod\s+777/i,
];

// In-memory sessions (simple + local)
type Session = { token: string; user: { username: string }; createdAt: number };
const sessions = new Map<string, Session>();
const SESSION_TTL_MS = 24 * 60 * 60 * 1000;

function now() {
  return Date.now();
}

function cleanSessions() {
  const t = now();
  for (const [token, s] of sessions.entries()) {
    if (t - s.createdAt > SESSION_TTL_MS) sessions.delete(token);
  }
}

function newToken() {
  return crypto.randomBytes(24).toString("hex");
}

function safeJoinWorkspace(rel: string) {
  const cleaned = rel.replace(/^[\\/]+/, "");
  const abs = path.resolve(WORKSPACE_ROOT, cleaned);
  if (!abs.startsWith(WORKSPACE_ROOT)) {
    throw new Error("Path escape blocked");
  }
  return abs;
}

async function buildTree(dirAbs: string, baseAbs: string, depth: number, maxDepth: number, limit: { n: number }) {
  if (limit.n <= 0) return [];
  if (depth > maxDepth) return [];

  let entries: any[] = [];
  try {
    entries = await fs.readdir(dirAbs, { withFileTypes: true });
  } catch {
    return [];
  }

  const out: any[] = [];
  for (const e of entries) {
    if (limit.n-- <= 0) break;
    // Skip noisy folders
    if (e.name === "node_modules" || e.name === ".git" || e.name === ".vite" || e.name === "dist") {
      continue;
    }

    const abs = path.join(dirAbs, e.name);
    const rel = path.relative(baseAbs, abs).replace(/\\/g, "/");

    if (e.isDirectory()) {
      out.push({ type: "dir", name: e.name, path: rel, children: await buildTree(abs, baseAbs, depth + 1, maxDepth, limit) });
    } else {
      out.push({ type: "file", name: e.name, path: rel });
    }
  }

  // sort: dirs first then files, alphabetically
  out.sort((a, b) => {
    if (a.type !== b.type) return a.type === "dir" ? -1 : 1;
    return a.name.localeCompare(b.name);
  });
  return out;
}

async function ollamaChat(payload: any) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), OLLAMA_TIMEOUT_MS);
  try {
    const r = await fetch(`${OLLAMA_URL}/api/chat`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(payload),
      signal: ctrl.signal,
    });
    const ct = r.headers.get("content-type") || "";
    const data = ct.includes("application/json") ? await r.json().catch(() => ({})) : await r.text();
    if (!r.ok) {
      const msg = typeof data === "string" ? data : data?.error || JSON.stringify(data);
      return { ok: false, error: msg || `HTTP ${r.status}` };
    }
    return { ok: true, data };
  } catch (e: any) {
    const msg = e?.name === "AbortError" ? "Ollama timeout" : e?.message || "Ollama fetch failed";
    return { ok: false, error: msg };
  } finally {
    clearTimeout(timer);
  }
}

// =====================
// App
// =====================
const app = express();

app.use(
  cors({
    origin: ["http://127.0.0.1:5173", "http://localhost:5173"],
    credentials: true,
  })
);
app.use(express.json({ limit: "2mb" }));
app.use(cookieParser());

// Health
app.get("/api/health", (req, res) => {
  res.json({ ok: true, name: "Sovereign Console v2", port: PORT });
});

function getSession(req: express.Request) {
  cleanSessions();
  const token = (req.cookies?.[SESSION_COOKIE] || "") as string;
  if (!token) return null;
  const s = sessions.get(token);
  if (!s) return null;
  return s;
}

function requireAuth(req: express.Request, res: express.Response, next: express.NextFunction) {
  const s = getSession(req);
  if (!s) return res.status(401).json({ ok: false, error: "Not authenticated" });
  (req as any).user = s.user;
  next();
}

// Auth
app.post("/api/auth/login", (req, res) => {
  const { username, password } = (req.body || {}) as { username?: string; password?: string };
  if (!username || !password) return res.status(400).json({ ok: false, error: "Missing credentials" });
  if (username !== ADMIN_USER || password !== ADMIN_PASS) return res.status(403).json({ ok: false, error: "Invalid credentials" });

  const token = newToken();
  sessions.set(token, { token, user: { username }, createdAt: now() });
  res.cookie(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
  });
  res.json({ ok: true, user: { username } });
});

app.get("/api/auth/me", (req, res) => {
  const s = getSession(req);
  if (!s) return res.status(401).json({ ok: false, error: "Not authenticated" });
  res.json({ ok: true, user: s.user });
});

app.post("/api/auth/logout", (req, res) => {
  const token = (req.cookies?.[SESSION_COOKIE] || "") as string;
  if (token) sessions.delete(token);
  res.clearCookie(SESSION_COOKIE);
  res.json({ ok: true });
});

// Workspace tree
app.get("/api/fs/tree", requireAuth, async (req, res) => {
  const rel = String(req.query.path || "");
  const depth = Math.max(1, Math.min(6, Number(req.query.depth || 4)));
  try {
    const abs = safeJoinWorkspace(rel);
    const limit = { n: 4000 };
    const children = await buildTree(abs, abs, 0, depth, limit);
    res.json({ ok: true, path: rel || ".", root: { type: "dir", name: path.basename(abs) || "workspace", path: rel || "", children } });
  } catch (e: any) {
    res.status(400).json({ ok: false, error: e?.message || "Tree failed" });
  }
});

// Read file
app.post("/api/fs/read", requireAuth, async (req, res) => {
  const { path: rel } = (req.body || {}) as { path?: string };
  if (!rel) return res.status(400).json({ ok: false, error: "Missing path" });
  try {
    const abs = safeJoinWorkspace(rel);
    const buf = await fs.readFile(abs);
    // return as text (best-effort)
    res.json({ ok: true, path: rel, content: buf.toString("utf8") });
  } catch (e: any) {
    res.status(400).json({ ok: false, error: e?.message || "Read failed" });
  }
});

// Write file
app.post("/api/fs/write", requireAuth, async (req, res) => {
  const { path: rel, content } = (req.body || {}) as { path?: string; content?: string };
  if (!rel) return res.status(400).json({ ok: false, error: "Missing path" });
  if (typeof content !== "string") return res.status(400).json({ ok: false, error: "Missing content" });
  try {
    const abs = safeJoinWorkspace(rel);
    await fs.mkdir(path.dirname(abs), { recursive: true });
    await fs.writeFile(abs, content, "utf8");
    res.json({ ok: true, path: rel });
  } catch (e: any) {
    res.status(400).json({ ok: false, error: e?.message || "Write failed" });
  }
});

// Exec command (admin-only allowlist)
app.post("/api/exec", requireAuth, async (req, res) => {
  const { cmd, cwd } = (req.body || {}) as { cmd?: string[]; cwd?: string };
  if (!Array.isArray(cmd) || cmd.length === 0) return res.status(400).json({ ok: false, error: "Missing cmd" });

  const bin = String(cmd[0] || "");
  if (!EXEC_ALLOWLIST.has(bin)) return res.status(403).json({ ok: false, error: `Command not allowed: ${bin}` });

  const joined = cmd.join(" ");
  if (EXEC_DENY_PATTERNS.some((p) => p.test(joined))) {
    return res.status(403).json({ ok: false, error: "Command blocked by safety policy" });
  }

  let execCwd = WORKSPACE_ROOT;
  try {
    if (cwd) execCwd = safeJoinWorkspace(String(cwd));
  } catch {
    // ignore and keep workspace root
  }

  const child = spawn(bin, cmd.slice(1), {
    cwd: execCwd,
    env: process.env,
  });

  let out = "";
  let err = "";

  child.stdout.on("data", (d) => (out += d.toString()));
  child.stderr.on("data", (d) => (err += d.toString()));

  child.on("close", (code) => {
    res.json({ ok: true, code, stdout: out.slice(-20000), stderr: err.slice(-20000) });
  });
});

// AI Chat proxy (safe, never crash)
app.post("/api/ai/chat", requireAuth, async (req, res) => {
  const { messages, model } = (req.body || {}) as { messages?: any[]; model?: string };
  if (!Array.isArray(messages) || messages.length === 0) {
    return res.status(400).json({ ok: false, error: "Missing messages" });
  }

  const payload = {
    model: model || OLLAMA_MODEL,
    messages,
    stream: false,
  };

  const r = await ollamaChat(payload);
  if (!r.ok) return res.status(503).json(r);
  res.json({ ok: true, response: r.data });
});

app.listen(PORT, "127.0.0.1", () => {
  console.log(`✅ Sovereign Console v2 backend running at http://127.0.0.1:${PORT}`);
  console.log(`✅ WORKSPACE_ROOT = ${WORKSPACE_ROOT}`);
});
