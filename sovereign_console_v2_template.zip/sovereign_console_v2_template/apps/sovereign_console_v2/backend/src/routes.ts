import type { Express } from "express";
import { z } from "zod";
import fs from "fs";
import { execFile } from "child_process";
import path from "path";

import { signToken, requireAuth } from "./auth.js";
import { buildTree, resolveInWorkspace } from "./workspace.js";
import { isAllowedCommand } from "./allowlist.js";

export function registerRoutes(app: Express, env: any) {
  const authed = requireAuth(env.SESSION_SECRET);

  app.get("/api/health", (_req, res) => {
    res.json({ ok: true, name: "Sovereign Console v2", port: env.PORT });
  });

  // --------------------
  // AUTH
  // --------------------
  app.post("/api/auth/login", (req, res) => {
    const schema = z.object({ username: z.string(), password: z.string() });
    const parsed = schema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ ok: false, error: "Bad request" });

    const { username, password } = parsed.data;
    if (username !== env.ADMIN_USER || password !== env.ADMIN_PASS) {
      return res.status(401).json({ ok: false, error: "Invalid credentials" });
    }

    const payload = JSON.stringify({ username, role: "admin" });
    const tok = signToken(payload, env.SESSION_SECRET);
    res.cookie("scv2", tok, {
      httpOnly: true,
      sameSite: "lax"
    });

    res.json({ ok: true, user: { username, role: "admin" } });
  });

  app.get("/api/auth/me", (req, res) => {
    const tok = req.cookies?.scv2 || "";
    // Lazy verify: reuse middleware but we want 200 ok:false
    try {
      // will throw if invalid
      (requireAuth(env.SESSION_SECRET) as any)(req, res, () => {
        const u = (req as any).user ? JSON.parse((req as any).user) : null;
        res.json({ ok: true, user: u });
      });
    } catch {
      res.json({ ok: false, error: "Not authenticated" });
    }
  });

  app.post("/api/auth/logout", (_req, res) => {
    res.clearCookie("scv2");
    res.json({ ok: true });
  });

  // --------------------
  // FILESYSTEM
  // --------------------
  app.get("/api/fs/tree", authed, (req, res) => {
    const rel = typeof req.query.path === "string" ? req.query.path : "";
    const depth = Number(req.query.depth || 4);
    const tree = buildTree(env.WORKSPACE_ROOT, rel, Math.min(Math.max(depth, 1), 8));
    res.json({ ok: true, tree });
  });

  app.post("/api/fs/read", authed, (req, res) => {
    const schema = z.object({ path: z.string() });
    const parsed = schema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ ok: false, error: "Bad request" });

    const abs = resolveInWorkspace(env.WORKSPACE_ROOT, parsed.data.path);
    if (!fs.existsSync(abs)) return res.status(404).json({ ok: false, error: "Not found" });

    const st = fs.statSync(abs);
    if (st.isDirectory()) return res.status(400).json({ ok: false, error: "Path is a directory" });

    const content = fs.readFileSync(abs, "utf8");
    res.json({ ok: true, content });
  });

  app.post("/api/fs/write", authed, (req, res) => {
    const schema = z.object({ path: z.string(), content: z.string() });
    const parsed = schema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ ok: false, error: "Bad request" });

    const abs = resolveInWorkspace(env.WORKSPACE_ROOT, parsed.data.path);
    fs.mkdirSync(path.dirname(abs), { recursive: true });
    fs.writeFileSync(abs, parsed.data.content, "utf8");
    res.json({ ok: true });
  });

  // --------------------
  // TERMINAL (allowlist)
  // --------------------
  app.post("/api/exec", authed, async (req, res) => {
    const schema = z.object({ cmd: z.string().min(1), cwd: z.string().optional() });
    const parsed = schema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ ok: false, error: "Bad request" });

    const { cmd, cwd } = parsed.data;
    if (!isAllowedCommand(cmd)) return res.status(403).json({ ok: false, error: "Command not allowed" });

    const parts = cmd.split(/\s+/);
    const bin = parts[0];
    const args = parts.slice(1);

    let workdir = env.WORKSPACE_ROOT;
    if (cwd) {
      try {
        workdir = resolveInWorkspace(env.WORKSPACE_ROOT, cwd);
      } catch {
        return res.status(400).json({ ok: false, error: "Invalid cwd" });
      }
    }

    execFile(bin, args, { cwd: workdir, timeout: 120000, maxBuffer: 1024 * 1024 }, (err, stdout, stderr) => {
      if (err) {
        return res.json({ ok: false, error: String(err.message || err), stdout, stderr });
      }
      res.json({ ok: true, stdout, stderr });
    });
  });

  // --------------------
  // AI (Ollama proxy) - NEVER CRASH
  // --------------------
  app.post("/api/ai/chat", authed, async (req, res) => {
    const schema = z.object({ messages: z.array(z.object({ role: z.enum(["system", "user", "assistant"]), content: z.string() })) });
    const parsed = schema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ ok: false, error: "Bad request" });

    const controller = new AbortController();
    const to = setTimeout(() => controller.abort(), env.OLLAMA_TIMEOUT_MS);

    try {
      const r = await fetch(`${env.OLLAMA_URL}/api/chat`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ model: env.OLLAMA_MODEL, messages: parsed.data.messages, stream: false }),
        signal: controller.signal
      });

      const data = await r.json().catch(() => ({}));
      if (!r.ok) {
        const msg = (data as any)?.error || `HTTP ${r.status}`;
        return res.json({ ok: false, error: msg });
      }

      const text = (data as any)?.message?.content ?? "";
      res.json({ ok: true, message: text, raw: data });
    } catch (e: any) {
      const msg = e?.name === "AbortError" ? "Ollama timeout" : (e?.message || "AI request failed");
      res.json({ ok: false, error: msg });
    } finally {
      clearTimeout(to);
    }
  });
}
