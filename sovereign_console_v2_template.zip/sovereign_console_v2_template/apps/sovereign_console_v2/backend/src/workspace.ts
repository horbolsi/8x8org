import fs from "fs";
import path from "path";

export function resolveInWorkspace(root: string, p: string) {
  const abs = path.resolve(root, p.replace(/^\/+/, ""));
  const rootAbs = path.resolve(root);
  if (!abs.startsWith(rootAbs)) {
    throw new Error("Path escapes workspace");
  }
  return abs;
}

export type TreeNode = {
  name: string;
  path: string;
  type: "file" | "dir";
  children?: TreeNode[];
};

export function buildTree(root: string, rel = "", maxDepth = 4, maxEntries = 5000): TreeNode {
  const start = resolveInWorkspace(root, rel || ".");
  let count = 0;

  function walk(abs: string, relPath: string, depth: number): TreeNode {
    const st = fs.statSync(abs);
    const name = path.basename(abs);

    if (st.isDirectory()) {
      const node: TreeNode = { name, path: relPath || "", type: "dir", children: [] };
      if (depth <= 0) return node;

      const entries = fs.readdirSync(abs, { withFileTypes: true });
      for (const e of entries) {
        if (count++ > maxEntries) break;
        if (e.name === "node_modules" || e.name === ".git") continue;
        const childAbs = path.join(abs, e.name);
        const childRel = relPath ? path.posix.join(relPath, e.name) : e.name;
        try {
          node.children!.push(walk(childAbs, childRel, depth - 1));
        } catch {
          // ignore unreadable
        }
      }
      return node;
    }

    return { name, path: relPath, type: "file" };
  }

  return walk(start, rel === "." ? "" : rel, maxDepth);
}
