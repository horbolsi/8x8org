// Very conservative allowlist for demo.
// You can expand safely (no rm, no sudo, no writing outside workspace).
export const ALLOWED_CMDS = new Set([
  "ls",
  "pwd",
  "whoami",
  "node",
  "npm",
  "pnpm",
  "yarn",
  "python",
  "python3",
  "pip",
  "pip3",
  "git",
  "rg",
  "cat",
  "head",
  "tail",
  "sed",
  "grep",
  "tree"
]);

export function isAllowedCommand(cmd: string) {
  const first = cmd.trim().split(/\s+/)[0] || "";
  return ALLOWED_CMDS.has(first);
}
