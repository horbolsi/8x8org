import type { Request, Response, NextFunction } from "express";
import crypto from "crypto";

export function signToken(payload: string, secret: string) {
  const h = crypto.createHmac("sha256", secret).update(payload).digest("hex");
  return `${payload}.${h}`;
}

export function verifyToken(token: string, secret: string) {
  const parts = token.split(".");
  if (parts.length < 2) return null;
  const payload = parts.slice(0, -1).join(".");
  const sig = parts[parts.length - 1];
  const expected = crypto.createHmac("sha256", secret).update(payload).digest("hex");
  if (crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return payload;
  return null;
}

export function requireAuth(secret: string) {
  return (req: Request, res: Response, next: NextFunction) => {
    const tok = req.cookies?.scv2 || "";
    const payload = tok ? verifyToken(tok, secret) : null;
    if (!payload) return res.status(401).json({ ok: false, error: "Not authenticated" });
    (req as any).user = payload;
    next();
  };
}
