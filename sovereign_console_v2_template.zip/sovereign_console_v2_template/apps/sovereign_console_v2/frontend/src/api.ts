function normalize(p: string) {
  if (!p.startsWith("/")) return "/" + p;
  return p;
}

type ExtraHeaders = Record<string, string>;

async function apiRequest(
  method: "GET" | "POST",
  path: string,
  body?: any,
  extraHeaders?: ExtraHeaders
) {
  const url = normalize(path);
  const r = await fetch(url, {
    method,
    credentials: "include",
    headers: {
      "content-type": "application/json",
      ...(extraHeaders || {}),
    },
    body: method === "GET" ? undefined : JSON.stringify(body ?? {}),
  });

  const ct = r.headers.get("content-type") || "";
  const data = ct.includes("application/json")
    ? await r.json().catch(() => ({}))
    : await r.text();

  if (!r.ok) {
    const msg = typeof data === "string" ? data : (data as any)?.error || JSON.stringify(data);
    throw new Error(msg || `HTTP ${r.status}`);
  }

  return data;
}

export async function apiGet<T = any>(path: string, extraHeaders?: ExtraHeaders): Promise<T> {
  return apiRequest("GET", path, undefined, extraHeaders) as Promise<T>;
}

export async function apiPost<T = any>(path: string, body?: any, extraHeaders?: ExtraHeaders): Promise<T> {
  return apiRequest("POST", path, body, extraHeaders) as Promise<T>;
}
