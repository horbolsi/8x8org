import React, { useEffect, useMemo, useState } from "react";
import { apiGet, apiPost } from "./api";

type User = {
  username: string;
};

type TreeNode = {
  name: string;
  path: string;
  type: "file" | "dir";
  children?: TreeNode[];
};

type ChatMsg = { role: "user" | "assistant" | "system"; content: string };

function splitCommand(input: string): string[] {
  // Basic shell-like split (supports quotes)
  const out: string[] = [];
  let cur = "";
  let quote: "'" | '"' | null = null;
  for (let i = 0; i < input.length; i++) {
    const ch = input[i];
    if (quote) {
      if (ch === quote) {
        quote = null;
      } else {
        cur += ch;
      }
      continue;
    }
    if (ch === "'" || ch === '"') {
      quote = ch;
      continue;
    }
    if (ch === " ") {
      if (cur) {
        out.push(cur);
        cur = "";
      }
      continue;
    }
    cur += ch;
  }
  if (cur) out.push(cur);
  return out;
}

function TreeView({ node, onOpen }: { node: TreeNode; onOpen: (p: string) => void }) {
  const [open, setOpen] = useState(false);
  const isDir = node.type === "dir";

  return (
    <div style={{ marginLeft: 10 }}>
      <div
        className="treeRow"
        onClick={() => {
          if (isDir) setOpen((v) => !v);
          else onOpen(node.path);
        }}
      >
        <span className="treeIcon">{isDir ? (open ? "📂" : "📁") : "📄"}</span>
        <span className="treeLabel">{node.name}</span>
      </div>
      {isDir && open && node.children?.map((c) => <TreeView key={c.path} node={c} onOpen={onOpen} />)}
    </div>
  );
}

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [authError, setAuthError] = useState<string>("");
  const [loginUser, setLoginUser] = useState("admin");
  const [loginPass, setLoginPass] = useState("admin");

  const [tree, setTree] = useState<TreeNode | null>(null);
  const [selectedPath, setSelectedPath] = useState<string>("");
  const [fileText, setFileText] = useState<string>("");
  const [fileDirty, setFileDirty] = useState(false);

  const [termCmd, setTermCmd] = useState<string>("rg -n \"TODO\" .");
  const [termOut, setTermOut] = useState<string>("");
  const [termErr, setTermErr] = useState<string>("");

  const [chatMsgs, setChatMsgs] = useState<ChatMsg[]>([
    {
      role: "system",
      content:
        "You are SCV2 local assistant. Help with safe repo edits, debugging, and feature improvements. Prefer small patches and explain commands.",
    },
  ]);
  const [chatInput, setChatInput] = useState<string>("hello");
  const [chatBusy, setChatBusy] = useState(false);

  const canEdit = useMemo(() => selectedPath && selectedPath.length > 0, [selectedPath]);

  async function refreshMe() {
    try {
      const me = await apiGet<any>("/api/auth/me");
      if (me.ok) setUser(me.user);
      else setUser(null);
    } catch {
      setUser(null);
    }
  }

  async function refreshTree() {
    const res = await apiGet<any>("/api/fs/tree?depth=4");
    if (res.ok) setTree(res.tree);
  }

  async function openFile(p: string) {
    setSelectedPath(p);
    setFileDirty(false);
    const res = await apiPost<any>("/api/fs/read", { path: p });
    if (res.ok) setFileText(res.text ?? "");
  }

  async function saveFile() {
    if (!selectedPath) return;
    const res = await apiPost<any>("/api/fs/write", { path: selectedPath, text: fileText });
    if (res.ok) {
      setFileDirty(false);
      await refreshTree();
    }
  }

  async function login() {
    setAuthError("");
    try {
      const j = await apiPost<any>("/api/auth/login", { username: loginUser, password: loginPass });
      if (j.ok) {
        setUser(j.user);
        await refreshTree();
      } else {
        setAuthError(j.error || "Login failed");
      }
    } catch (e: any) {
      setAuthError(String(e?.message || e));
    }
  }

  async function logout() {
    await apiPost<any>("/api/auth/logout", {});
    setUser(null);
    setTree(null);
    setSelectedPath("");
    setFileText("");
    setTermOut("");
    setTermErr("");
  }

  async function runCommand() {
    setTermOut("");
    setTermErr("");
    try {
      const cmd = splitCommand(termCmd);
      const res = await apiPost<any>("/api/exec", { cmd });
      if (res.ok) {
        setTermOut(res.stdout || "");
        setTermErr(res.stderr || "");
      } else {
        setTermErr(res.error || "Exec failed");
      }
    } catch (e: any) {
      setTermErr(String(e?.message || e));
    }
  }

  async function sendChat() {
    if (!chatInput.trim()) return;
    const nextMsgs: ChatMsg[] = [...chatMsgs, { role: "user", content: chatInput }];
    setChatMsgs(nextMsgs);
    setChatInput("");
    setChatBusy(true);
    try {
      const res = await apiPost<any>("/api/ai/chat", { messages: nextMsgs });
      if (res.ok) {
        setChatMsgs([...nextMsgs, { role: "assistant", content: res.reply || "" }]);
      } else {
        setChatMsgs([...nextMsgs, { role: "assistant", content: `⚠️ ${res.error || "AI error"}` }]);
      }
    } catch (e: any) {
      setChatMsgs([...nextMsgs, { role: "assistant", content: `⚠️ ${String(e?.message || e)}` }]);
    } finally {
      setChatBusy(false);
    }
  }

  useEffect(() => {
    refreshMe();
  }, []);

  useEffect(() => {
    if (user) refreshTree();
  }, [user]);

  return (
    <div className="app">
      <header className="header">
        <div className="title">
          <div className="h1">Sovereign Console v2</div>
          <div className="sub">Local workspace dashboard + safe tools + local AI</div>
        </div>
        <div className="right">
          {user ? (
            <>
              <div className="chip">✅ online</div>
              <div className="chip">Logged in: {user.username}</div>
              <button className="btn" onClick={refreshTree}>
                Reload Tree
              </button>
              <button className="btn danger" onClick={logout}>
                Logout
              </button>
            </>
          ) : (
            <div className="chip">Not authenticated</div>
          )}
        </div>
      </header>

      {!user ? (
        <div className="login">
          <div className="card">
            <div className="cardTitle">Login</div>
            <div className="row">
              <label>Username</label>
              <input value={loginUser} onChange={(e) => setLoginUser(e.target.value)} />
            </div>
            <div className="row">
              <label>Password</label>
              <input type="password" value={loginPass} onChange={(e) => setLoginPass(e.target.value)} />
            </div>
            {authError ? <div className="error">{authError}</div> : null}
            <button className="btn primary" onClick={login}>
              Login
            </button>
            <div className="hint">
              Default: <code>admin/admin</code> (change in backend env)
            </div>
          </div>
        </div>
      ) : (
        <div className="grid">
          <aside className="panel">
            <div className="panelTitle">Workspace</div>
            <div className="panelBody">
              {tree ? <TreeView node={tree} onOpen={openFile} /> : <div className="muted">Loading tree...</div>}
            </div>
          </aside>

          <section className="panel">
            <div className="panelTitle">Editor</div>
            <div className="panelBody">
              {!canEdit ? (
                <div className="muted">Select a file to open</div>
              ) : (
                <>
                  <div className="editorBar">
                    <div className="path">{selectedPath}</div>
                    <button className="btn" disabled={!fileDirty} onClick={saveFile}>
                      Save
                    </button>
                  </div>
                  <textarea
                    className="editor"
                    value={fileText}
                    onChange={(e) => {
                      setFileText(e.target.value);
                      setFileDirty(true);
                    }}
                  />
                </>
              )}
            </div>
          </section>

          <section className="panel">
            <div className="panelTitle">Terminal (Admin allowlist)</div>
            <div className="panelBody">
              <div className="rowInline">
                <input className="termInput" value={termCmd} onChange={(e) => setTermCmd(e.target.value)} />
                <button className="btn" onClick={runCommand}>
                  Run
                </button>
              </div>
              {termErr ? <pre className="termErr">{termErr}</pre> : null}
              {termOut ? <pre className="termOut">{termOut}</pre> : null}
            </div>
          </section>

          <section className="panel">
            <div className="panelTitle">AI Assistant (Ollama)</div>
            <div className="panelBody chat">
              <div className="chatLog">
                {chatMsgs
                  .filter((m) => m.role !== "system")
                  .map((m, idx) => (
                    <div key={idx} className={`msg ${m.role}`}>
                      <div className="role">{m.role}</div>
                      <div className="bubble">{m.content}</div>
                    </div>
                  ))}
              </div>
              <div className="chatBar">
                <input
                  className="chatInput"
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") sendChat();
                  }}
                  placeholder={chatBusy ? "Thinking..." : "Ask the assistant..."}
                  disabled={chatBusy}
                />
                <button className="btn primary" onClick={sendChat} disabled={chatBusy}>
                  Send
                </button>
              </div>
              <div className="hint">
                Tip: Run <code>ollama serve</code> and pull a model. If Ollama is offline, you’ll see a safe error (no crash).
              </div>
            </div>
          </section>
        </div>
      )}

      <footer className="footer">
        <div className="muted">
          Next upgrades: multi-file patch jobs + approve/run/rollback, repo-context chat, safer shell parsing, and pluggable AI providers.
        </div>
      </footer>
    </div>
  );
}
