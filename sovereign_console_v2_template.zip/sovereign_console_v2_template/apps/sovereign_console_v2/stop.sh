#!/usr/bin/env bash
set -euo pipefail

# Stop Sovereign Console v2 (best-effort)

pkill -f "tsx watch src/server.ts" 2>/dev/null || true
pkill -f "node .*vite" 2>/dev/null || true
pkill -f "vite --host" 2>/dev/null || true

kill_port() {
  local port="$1"
  if command -v lsof >/dev/null 2>&1; then
    local pid
    pid="$(lsof -ti tcp:"$port" 2>/dev/null || true)"
    if [ -n "${pid:-}" ]; then
      kill -9 $pid 2>/dev/null || true
    fi
  elif command -v fuser >/dev/null 2>&1; then
    fuser -k "${port}/tcp" 2>/dev/null || true
  fi
}

kill_port 6060
kill_port 5173

echo "✅ stopped (best-effort)"
