#!/usr/bin/env bash
set -euo pipefail

APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "$APP_DIR/../.." && pwd)"
BACK="$APP_DIR/backend"
FRONT="$APP_DIR/frontend"

echo "===================================================="
echo "🧠 SCV2 DOCTOR CHECK"
echo "===================================================="
echo

echo "ROOT:  $ROOT_DIR"
echo "APP:   $APP_DIR"
echo "FRONT: $FRONT"
echo "BACK:  $BACK"
echo

echo "==> Processes"
ps aux | grep -E "vite|tsx watch src/server.ts" | grep -v grep || echo "⚠️ no SCV2 processes detected"
echo

echo "==> Backend health"
(curl -sS http://127.0.0.1:6060/api/health && echo) || echo "❌ backend /api/health failed"
echo

echo "==> Frontend proxy test"
(curl -sS http://127.0.0.1:5173/api/health && echo) || echo "❌ frontend proxy /api/health failed"
echo

echo "==> Frontend logs (last 30)"
tail -n 30 "$APP_DIR/runtime/logs/frontend.out" 2>/dev/null || true

echo

echo "==> Backend logs (last 30)"
tail -n 30 "$APP_DIR/runtime/logs/backend.out" 2>/dev/null || true

echo

echo "===================================================="
echo "✅ DOCTOR DONE"
echo "===================================================="
