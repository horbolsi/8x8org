# Sovereign Console v2 (Template)

This is a **portable full‑stack dev console** designed to run on:
- ✅ Termux (Android)
- ✅ Linux / macOS
- ✅ Replit (with small tweaks)

It includes:
- **React + Vite frontend** (dashboard)
- **Node + Express backend** (workspace API)
- **Cookie login (admin)**
- **Workspace browser + editor**
- **Safe terminal runner (allowlist + denylist)**
- **Local AI chat proxy** (Ollama) with **timeout safety** (won't crash your backend)

## 1) Quick start

From `apps/sovereign_console_v2`:

```bash
bash start.sh
```

Open:
- Frontend: `http://127.0.0.1:5173`
- Backend health: `http://127.0.0.1:6060/api/health`

Default login:
- user: `admin`
- pass: `admin`

## 2) Folder structure

```
apps/sovereign_console_v2/
  backend/
  frontend/
  runtime/logs/
  start.sh
  stop.sh
  doctor.sh
```

## 3) Configure workspace root

The backend needs to know what folder is your main repo:

```bash
export WORKSPACE_ROOT="$HOME/repos/8x8org"
```

`start.sh` auto‑sets this to the repository root if it can.

## 4) Ollama (Local AI)

Install and run Ollama, then set:

```bash
export OLLAMA_URL="http://127.0.0.1:11434"
export OLLAMA_MODEL="llama3.2"
```

If Ollama is not running, AI requests will return a friendly error instead of crashing.

## 5) Security notes

This template is intentionally "safe by default":
- Terminal runs through an **allowlist** and blocks dangerous commands
- File read/write is limited to `WORKSPACE_ROOT`
- Auth is required for all workspace operations

If you expose this publicly, you must add stronger auth and rate limits.

---

## For AI-assisted maintenance

Give your AI this repo and tell it:

- Never edit files outside `apps/sovereign_console_v2/`
- Prefer patching with small diffs
- Run `bash doctor.sh` after changes
- Keep backend stable (never crash on AI timeouts)

