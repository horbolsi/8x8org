# AI Workflow (How to Improve This Repo)

This repo is designed so **other AIs** (or humans) can:
- inspect the workspace (tree, open files)
- apply safe patches
- run controlled commands
- verify changes with quick tests

## Golden rules
1. Always read logs in: `apps/sovereign_console_v2/runtime/logs/`
2. Never run destructive commands (rm -rf, format, etc.)
3. Patch in small steps, then re-run:
   - `curl http://127.0.0.1:6060/api/health`
   - open `http://127.0.0.1:5173`

## Dev loop
```bash
cd apps/sovereign_console_v2
./stop.sh || true
./start.sh
./doctor.sh
```

## Typical patch process
1. Reproduce the issue (check console/logs)
2. Identify file(s)
3. Apply minimal patch
4. Restart + smoke test
5. Commit the diff

## Suggested commands (safe)
- `rg "pattern"` (ripgrep search)
- `tail -n 200 runtime/logs/backend.out`
- `tail -n 200 runtime/logs/frontend.out`
- `npm -v && node -v`

