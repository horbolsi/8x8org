#!/usr/bin/env bash
set -euo pipefail
bash "$(cd "$(dirname "$0")" && pwd)/apps/sovereign_console_v2/stop.sh"
